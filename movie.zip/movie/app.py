import pandas as pd
import requests
from bs4 import BeautifulSoup

# Load the links
links = pd.read_csv('links.csv')

# Example of scraping function
def get_imdb_rating(imdb_link):
    try:
        response = requests.get(imdb_link)
        soup = BeautifulSoup(response.content, 'html.parser')
        rating = soup.find('span', itemprop='ratingValue').text
        return float(rating)
    except Exception as e:
        print(f"Error scraping {imdb_link}: {e}")
        return None

# Add IMDB rating to the filtered movies dataframe
filtered_movies['IMDB_Rating'] = filtered_movies['movieId'].map(lambda x: get_imdb_rating(links.loc[links['movieId'] == x, 'IMDB_Link'].values[0]))

# Find the movie with the highest IMDB rating
highest_imdb_movie = filtered_movies.loc[filtered_movies['IMDB_Rating'].idxmax()]
highest_imdb_movie_id = highest_imdb_movie['movieId']
print(f"Movie ID with the highest IMDB rating: {highest_imdb_movie_id}")

# Filter for Sci-Fi movies and find the highest IMDB rating
sci_fi_movies = filtered_movies[filtered_movies['title'].str.contains('Sci-Fi', case=False)]
highest_sci_fi_imdb_movie = sci_fi_movies.loc[sci_fi_movies['IMDB_Rating'].idxmax()]
highest_sci_fi_imdb_movie_id = highest_sci_fi_imdb_movie['movieId']
print(f"Sci-Fi movie ID with the highest IMDB rating: {highest_sci_fi_imdb_movie_id}")
